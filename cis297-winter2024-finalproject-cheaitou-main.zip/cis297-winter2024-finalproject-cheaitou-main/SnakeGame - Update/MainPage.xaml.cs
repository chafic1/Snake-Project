﻿using Microsoft.Graphics.Canvas;
using Microsoft.Graphics.Canvas.UI.Xaml;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Security.Cryptography.X509Certificates;
using System.Threading.Tasks;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Gaming.Input;
using Windows.UI;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Documents;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using Windows.UI.Xaml.Shapes;
using Windows.UI.Xaml.Media.Animation;
using SnakeGame___Update;

namespace SnakeGame___Update
{
    public sealed partial class MainPage : Page
    {
        bool snakeMovingRight;
        bool snakeMovingDown;
        bool snakeMovingUp;
        bool snakeMovingLeft;

        private CanvasBitmap mintImage;
        private static List<SnakeDrawing> drawables;

        SnakeRectangle leftWall;
        SnakeRectangle rightWall;
        SnakeRectangle topWall;
        SnakeRectangle bottomWall;

        SnakeCollision circle;
        SnakeRectangle food;

        bool snakeGoingRight;
        bool snakeGoingLeft;
        bool snakeGoingUp;
        bool snakeGoingDown;

        List<SnakeCollide> upAndDownCollidables;
        List<SnakeCollide> leftAndRightCollidables;
        public MainPage()
        {
            this.InitializeComponent();
            Window.Current.CoreWindow.KeyDown += Canvas_KeyDown;
            Window.Current.CoreWindow.KeyUp += Canvas_KeyUp;

            snakeGoingRight = false;
            snakeGoingUp = false;
            snakeGoingLeft = false;
            snakeGoingDown = false;

            drawables = new List<SnakeDrawing>();
            leftAndRightCollidables = new List<SnakeCollide>();
            upAndDownCollidables = new List<SnakeCollide>();

            snakeMovingRight = true;
            snakeMovingLeft = true;
            snakeMovingUp = true;
            snakeMovingDown = true;

            SnakeRectangle rectangle1 = new SnakeRectangle
            {
                X = 98,
                Y = 78,
                Width = 100,
                Height = 50,
                Color = Colors.Red
            };

            SnakeRectangle rectangle2 = new SnakeRectangle
            {
                X = 198,
                Y = 78,
                Width = 100,
                Height = 50,
                Color = Colors.Green
            };

            SnakeRectangle rectangle3 = new SnakeRectangle
            {
                X = 298,
                Y = 78,
                Width = 100,
                Height = 50,
                Color = Colors.Blue
            };

            SnakeRectangle rectangle4 = new SnakeRectangle
            {
                X = 398,
                Y = 78,
                Width = 100,
                Height = 50,
                Color = Colors.Purple
            };

            SnakeRectangle rectangle5 = new SnakeRectangle
            {
                X = 498,
                Y = 78,
                Width = 100,
                Height = 50,
                Color = Colors.Red
            };

            SnakeRectangle rectangle6 = new SnakeRectangle
            {
                X = 598,
                Y = 78,
                Width = 100,
                Height = 50,
                Color = Colors.Blue
            };

            circle = new SnakeCollision
            {
                X = 250,
                Y = 300,
                Radius = 10,
                Color = Colors.White
            };

            leftWall = new SnakeRectangle
            {
                X = 50,
                Y = 50,
                Width = 10,
                Height = 400,
                Color = Colors.White
            };

            drawables.Add(leftWall);
            drawables.Add(rightWall);
            drawables.Add(circle);
            drawables.Add(circle);
            drawables.Add(food);

            drawables.Add(rectangle1);
            drawables.Add(rectangle2);
            drawables.Add(rectangle3);
            drawables.Add(rectangle4);
            drawables.Add(rectangle5);
            drawables.Add(rectangle6);

            leftAndRightCollidables.Add(leftWall);
            leftAndRightCollidables.Add(rightWall);

            leftAndRightCollidables.Add(rectangle1);
            leftAndRightCollidables.Add(rectangle2);
            leftAndRightCollidables.Add(rectangle3);
            leftAndRightCollidables.Add(rectangle4);
            leftAndRightCollidables.Add(rectangle5);
            leftAndRightCollidables.Add(rectangle6);

            upAndDownCollidables.Add(rectangle1);
            upAndDownCollidables.Add(rectangle2);
            upAndDownCollidables.Add(rectangle3);
            upAndDownCollidables.Add(rectangle4);
            upAndDownCollidables.Add(rectangle5);
            upAndDownCollidables.Add(rectangle6);

            upAndDownCollidables.Add(circle);
            upAndDownCollidables.Add(food);
        }

        internal static void RemoveDrawable(SnakeDrawing drawable)
        {
            drawables.Remove(drawable);
        }

        private void Canvas_KeyDown(Windows.UI.Core.CoreWindow sender, Windows.UI.Core.KeyEventArgs e)
        {
            if (e.VirtualKey == Windows.System.VirtualKey.Left)
            {
                snakeGoingLeft = true;
            }
            else if (e.VirtualKey == Windows.System.VirtualKey.Right)
            {
                snakeGoingRight = true;
            }
        }
        private void Canvas_KeyUp(Windows.UI.Core.CoreWindow sender, Windows.UI.Core.KeyEventArgs e)
        {
            if (e.VirtualKey == Windows.System.VirtualKey.Left)
            {
                snakeGoingLeft = true;
            }
            else if (e.VirtualKey == Windows.System.VirtualKey.Right)
            {
                snakeGoingRight = true;
            }
        }
        private void Canvas_Draw(ICanvasAnimatedControl sender, CanvasAnimatedDrawEventArgs args)
        {
            foreach (var drawable in drawables)
            {
                drawable.Draw(args.DrawingSession);
            }
        }
        public void Canvas_Update(ICanvasAnimatedControl sender, CanvasAnimatedUpdateEventArgs args)
        {
            SnakeDrawing collidedDrawable = null;
            foreach (var colliable in upAndDownCollidables)
            {

                collidedDrawable = circle.CollidedObject(colliable);
                if (collidedDrawable != null)
                {
                    break;
                }
                if (colliable == food)
                {
                    continue;
                }
            }

            if (collidedDrawable != null)
            {
                if (collidedDrawable != food)
                {
                    RemoveDrawable(collidedDrawable as SnakeDrawing);

                }
            }

            foreach (var colliable in upAndDownCollidables)
            {
                if (circle.DidCollide(colliable))
                {
                    snakeMovingDown = !snakeMovingDown;
                }
            }

            foreach (var colliable in leftAndRightCollidables)
            {
                if (circle.DidCollide(colliable))
                {
                    snakeGoingRight = !snakeGoingRight;
                }
            }
            foreach (var colliable in leftAndRightCollidables)
            {
                if (circle.DidCollide(colliable))
                {
                    snakeGoingLeft = !snakeGoingLeft;
                }
            }
            foreach (var colliable in leftAndRightCollidables)
            {
                if (circle.DidCollide(colliable))
                {
                    snakeGoingUp = !snakeGoingUp;
                }
            }

            if (snakeMovingRight)
            {
                circle.X++;
            }
            else
            {
                circle.X--;
            }

            if (snakeMovingDown)
            {
                circle.Y++;
            }
            else
            {
                circle.Y--;
            }

            if (snakeGoingLeft)
            {
                if (!leftWall.DidCollide(leftWall))
                {
                    return;
                }

            }
            else if (snakeGoingRight)
            {
                if (!rightWall.DidCollide(rightWall))
                {
                    return;
                }
            }
            else if (snakeGoingDown)
            {
                if (!bottomWall.DidCollide(bottomWall))
                {
                    return;
                }
            }
            else if (snakeGoingUp)
            {
                if (!topWall.DidCollide(topWall))
                {
                    return;
                }
            }

            if (Gamepad.Gamepads.Count > 0)
            {
                Gamepad controller = Gamepad.Gamepads.First();
                var reading = controller.GetCurrentReading();
                bottomWall.X += (int)(reading.LeftThumbstickX * 5);
                topWall.X += (int)(reading.LeftThumbstickX * 5);
                rightWall.X += (int)(reading.LeftThumbstickX * 5);
                leftWall.X += (int)(reading.LeftThumbstickX * 5);
            }
        }
        private void ResetButton_Click(object sender, RoutedEventArgs e)
        {
            ResetGame();
        }

        private void ResetGame()
        {
            circle.X = 200;
            circle.Y = 200;

            topWall.X = 200;
            bottomWall.X = 200;
            rightWall.X = 200;
            leftWall.X = 200;

            SnakeRectangle rectangle1 = new SnakeRectangle
            {
                X = 100,
                Y = 78,
                Width = 100,
                Height = 50,
                Color = Colors.Red
            };

            SnakeRectangle rectangle2 = new SnakeRectangle
            {
                X = 200,
                Y = 78,
                Width = 100,
                Height = 50,
                Color = Colors.Green
            };

            SnakeRectangle rectangle3 = new SnakeRectangle
            {
                X = 300,
                Y = 78,
                Width = 100,
                Height = 50,
                Color = Colors.Blue
            };

            SnakeRectangle rectangle4 = new SnakeRectangle
            {
                X = 400,
                Y = 78,
                Width = 100,
                Height = 50,
                Color = Colors.Purple
            };

            SnakeRectangle rectangle5 = new SnakeRectangle
            {
                X = 500,
                Y = 78,
                Width = 100,
                Height = 50,
                Color = Colors.Red
            };

            SnakeRectangle rectangle6 = new SnakeRectangle
            {
                X = 600,
                Y = 78,
                Width = 100,
                Height = 50,
                Color = Colors.Blue
            };

            private void Canvas_CreateResources(CanvasAnimatedControl sender, Microsoft.Graphics.Canvas.UI.CanvasCreateResourcesEventArgs args)
            {
                args.TrackAsyncAction(CreateResources(sender).AsAsyncAction());
            }

            async Task CreateResources(Microsoft.Graphics.Canvas.UI.Xaml.CanvasAnimatedControl sender)
            {
                //mintImage = await CanvasBitmap.LoadAsync(sender, "Assets/mint.png");
                //circle.Image = mintImage;
            }
        }
    }
}