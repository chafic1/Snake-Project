﻿using Microsoft.Graphics.Canvas;
using Microsoft.Graphics.Canvas.Effects;
using SnakeGame___Update;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.System.RemoteSystems;
using Windows.UI;
using Windows.UI.Xaml.Media;

namespace SnakeGame___Update
{
    internal class SnakeCollision : SnakeDrawing, SnakeCollide
    {
        public int X { get; set; }
        public int Y { get; set; }
        public int Radius { get; set; }
        public Color Color { get; set; }

        private List<SnakeDrawing> drawables;

        public SnakeDrawing CollidedObject(SnakeCollide other)
        {
            if (GetLeftEdgeX() > other.GetRightEdgeX() ||
            GetRightEdgeX() < other.GetLeftEdgeX() ||
            GetTopEdgeY() > other.GetBottomEdgeY() ||
            GetBottomEdgeY() < other.GetTopEdgeY())
            {
                return null;
            }
            return other as SnakeDrawing;
        }

        public bool DidCollide(SnakeCollide other)
        {
            if (GetLeftEdgeX() > other.GetRightEdgeX())
                return false;

            if (GetRightEdgeX() < other.GetLeftEdgeX())
                return false;

            if (GetTopEdgeY() > other.GetBottomEdgeY())
                return false;

            if (GetBottomEdgeY() < other.GetTopEdgeY())
                return false;

            return true;
        }

        public void Draw(CanvasDrawingSession session)
        {
            session.FillCircle(X, Y, Radius, Color);
        }

        public int GetBottomEdgeY()
        {
            return Y + Radius;
        }

        public int GetLeftEdgeX()
        {
            return X;
        }

        public int GetRightEdgeX()
        {
            return X + Radius;
        }

        public int GetTopEdgeY()
        {
            return Y;
        }
    }
}