﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SnakeGame___Update
{
    internal interface SnakeCollide
    {
        int GetLeftEdgeX();
        int GetRightEdgeX();
        int GetBottomEdgeY();
        int GetTopEdgeY();

        bool DidCollide(SnakeCollide other);
    }
}