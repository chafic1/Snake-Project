﻿using Microsoft.Graphics.Canvas;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI;

namespace SnakeGame___Update
{
    internal class SnakeRectangle : SnakeDrawing, SnakeCollide
    {
        public int X { get; set; }
        public int Y { get; set; }
        public int Width { get; set; }
        public int Height { get; set; }
        public Color Color;

        public void Draw(CanvasDrawingSession session)
        {
            session.DrawRectangle(X, Y, Width, Height, Color);
        }

        public int GetLeftEdgeX()
        {
            return X;
        }

        public int GetRightEdgeX()
        {
            return X + Width;
        }

        public int GetBottomEdgeY()
        {
            return Y + Height;
        }

        public int GetTopEdgeY()
        {
            return Y;
        }

        public bool DidCollide(SnakeCollide other)
        {
            if (GetLeftEdgeX() > other.GetRightEdgeX())
                return false;

            if (GetRightEdgeX() < other.GetLeftEdgeX())
                return false;

            if (GetTopEdgeY() > other.GetBottomEdgeY())
                return false;

            if (GetBottomEdgeY() < other.GetTopEdgeY())
                return false;

            return true;
        }
    }
}